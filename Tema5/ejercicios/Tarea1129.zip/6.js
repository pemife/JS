window.onload = function (){
  botonVotar.addEventListener("click", recogerDatos);
  crearCookies();
}

function recogerDatos(){
  var resultado = document.getElementsByName('moviles').value;
  for (var input in resultado) {
    if(input.checked){
      sumarCookie(input.value);
    }
  }
}

function crearCookies(){
  var resultado = document.getElementsByName('moviles');
  for (input of resultado) {
    if(getCookie(input.value) != null ){
      setCookie(input.value, 0);
    }
  }
}
